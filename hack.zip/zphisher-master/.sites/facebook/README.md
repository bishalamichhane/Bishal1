# Facebook Static Login Form (Full offline css and js)

## Author: 《Bishal Lamichhane 》
#### This is created for educational purposes demonstrating how phishing works.
